export type Problem = {
  question: string
  answer: number
  options: number[]
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

// difficulty grows with how many you've answered correctly
export function generateProblem(correctCount: number): Problem {
  const level = Math.min(4, Math.floor(correctCount / 4))
  let a: number
  let b: number
  let op: "+" | "-" | "×"
  let answer: number

  const maxAdd = 10 + level * 8
  const maxMul = 3 + level * 2

  const roll = Math.random()
  if (level >= 2 && roll > 0.66) {
    op = "×"
    a = 1 + Math.floor(Math.random() * maxMul)
    b = 1 + Math.floor(Math.random() * maxMul)
    answer = a * b
  } else if (roll > 0.4) {
    op = "+"
    a = 1 + Math.floor(Math.random() * maxAdd)
    b = 1 + Math.floor(Math.random() * maxAdd)
    answer = a + b
  } else {
    op = "-"
    a = 1 + Math.floor(Math.random() * maxAdd)
    b = 1 + Math.floor(Math.random() * a)
    answer = a - b
  }

  const question = `${a} ${op} ${b}`

  // build 3 wrong options near the answer
  const wrong = new Set<number>()
  while (wrong.size < 3) {
    const delta = Math.floor(Math.random() * 7) - 3
    const candidate = answer + (delta === 0 ? 4 : delta)
    if (candidate >= 0 && candidate !== answer) wrong.add(candidate)
  }

  const options = shuffle([answer, ...Array.from(wrong)])
  return { question, answer, options }
}
