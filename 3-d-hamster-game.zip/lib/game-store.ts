"use client"

import { create } from "zustand"

// ----- Geometry: a world made of one or more connected cages (rooms) -----
// Rooms sit in a row along X with a gap between them, joined by a tunnel.
// CAGE = overall bounding box. GEO = detailed room + corridor layout.

export const CAGE = {
  minX: -5.2,
  maxX: 5.2,
  minZ: -5.2,
  maxZ: 5.2,
}

export const GEO = {
  half: 5.2,
  gap: 3.0,
  tunnelHalfWidth: 1.15,
  rooms: [{ cx: 0 }] as { cx: number }[],
  corridors: [] as { x0: number; x1: number }[],
}

export const MAX_ROOMS = 4
export const PLATFORM_H = 1.0
export const STAIR_LEN = 1.8
export const STAIR_W = 1.0
export const PLATFORM_HALF = 0.85

export type CageThemeId = "klassiek" | "bos" | "woestijn" | "ijs"

export type CageTheme = {
  id: CageThemeId
  label: string
  half: number
  floor: string
  bedding: string[]
  base: string
  rim: string
  glass: string
  background: string
  swatch: string
}

export const CAGE_THEMES: Record<CageThemeId, CageTheme> = {
  klassiek: {
    id: "klassiek",
    label: "Klassiek",
    half: 5.2,
    floor: "#e9d4a8",
    bedding: ["#e8d6b0", "#dcc59a", "#efe0bf", "#d4be8f"],
    base: "#7c5a3a",
    rim: "#a9764a",
    glass: "#bfe3ee",
    background: "#f3e3c4",
    swatch: "#e9d4a8",
  },
  bos: {
    id: "bos",
    label: "Bos",
    half: 6.0,
    floor: "#6f8f5a",
    bedding: ["#5f7d4c", "#7fa063", "#86603c", "#9fbf7d"],
    base: "#4a5d39",
    rim: "#6b4a2c",
    glass: "#cfeede",
    background: "#dbe7cb",
    swatch: "#6f8f5a",
  },
  woestijn: {
    id: "woestijn",
    label: "Woestijn",
    half: 6.6,
    floor: "#e7c486",
    bedding: ["#dcb673", "#efd49a", "#cfa860", "#f0dcae"],
    base: "#b58a52",
    rim: "#c79a5c",
    glass: "#f3e7c8",
    background: "#f6e8c8",
    swatch: "#e7c486",
  },
  ijs: {
    id: "ijs",
    label: "IJs",
    half: 6.0,
    floor: "#d6e8f2",
    bedding: ["#c4dcea", "#e6f1f8", "#b3d0e0", "#eaf4fb"],
    base: "#7c93a3",
    rim: "#9fb6c6",
    glass: "#dff1fb",
    background: "#e4f0f7",
    swatch: "#d6e8f2",
  },
}

export type ToolType =
  | "walk"
  | "hamster"
  | "bug"
  | "block"
  | "wheel"
  | "tunnel"
  | "ladder"
  | "stairs"
  | "platform"
  | "bowl"
  | "food"

export type ItemType = "block" | "wheel" | "tunnel" | "ladder" | "stairs" | "platform" | "bowl" | "food"

export type PlacedItem = {
  id: string
  type: ItemType
  x: number
  z: number
  color: string
  rotation: number
}

export type Hamster = {
  id: string
  color: string
  belly: string
  scale: number
  startX: number
  startZ: number
  target: { x: number; z: number } | null
}

export type Bug = {
  id: string
  x: number
  z: number
  kind: "kever" | "worm" | "sprinkhaan"
}

export const ITEM_COST: Record<ItemType, number> = {
  block: 1,
  food: 1,
  bowl: 3,
  ladder: 3,
  stairs: 4,
  tunnel: 5,
  platform: 6,
  wheel: 8,
}

export const HAMSTER_COST = 5
export const BUG_COST = 2
export const ROOM_COST = 12
export const MAX_HAMSTERS = 10
export const MAX_SCALE = 2.2

export const BLOCK_COLORS = [
  "#e8743b",
  "#f2c14e",
  "#5fb878",
  "#5b8def",
  "#e0654f",
  "#b87dd6",
]

// Fur + belly options for the hamster designer
export const FUR_COLORS = [
  "#c98a52",
  "#8a8a8a",
  "#e8c27a",
  "#a35e3a",
  "#f0f0f0",
  "#5a4636",
  "#d98b4a",
  "#2f2a26",
]

export const BELLY_COLORS = ["#f0d2a8", "#e8e8e8", "#fff1d6", "#ffffff", "#e9c39a", "#d8c0a4"]

const BUG_KINDS: Bug["kind"][] = ["kever", "worm", "sprinkhaan"]

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v))
}

let idCounter = 0
function nextId(prefix: string) {
  idCounter += 1
  return `${prefix}-${Date.now()}-${idCounter}`
}

// recompute room layout + bounds whenever theme or room count changes
function applyGeometry(themeId: CageThemeId, roomCount: number) {
  const half = CAGE_THEMES[themeId].half
  GEO.half = half
  const stepX = 2 * half + GEO.gap
  GEO.rooms = []
  for (let i = 0; i < roomCount; i++) GEO.rooms.push({ cx: i * stepX })
  GEO.corridors = []
  for (let i = 0; i < roomCount - 1; i++) {
    GEO.corridors.push({
      x0: GEO.rooms[i].cx + half,
      x1: GEO.rooms[i + 1].cx + half + GEO.gap === undefined ? 0 : GEO.rooms[i + 1].cx - half,
    })
  }
  CAGE.minX = GEO.rooms[0].cx - half
  CAGE.maxX = GEO.rooms[roomCount - 1].cx + half
  CAGE.minZ = -half
  CAGE.maxZ = half
}

// Is point inside any room rect or any connecting corridor?
export function insideUnion(x: number, z: number, r: number) {
  const half = GEO.half
  for (const room of GEO.rooms) {
    if (
      x >= room.cx - half + r &&
      x <= room.cx + half - r &&
      z >= -half + r &&
      z <= half - r
    ) {
      return true
    }
  }
  const zLimit = GEO.tunnelHalfWidth - r * 0.6
  if (zLimit > 0) {
    for (const c of GEO.corridors) {
      if (x >= c.x0 - r - 0.4 && x <= c.x1 + r + 0.4 && Math.abs(z) <= zLimit) {
        return true
      }
    }
  }
  return false
}

// Slide-along-walls movement constrained to the walkable union
export function containMovement(ox: number, oz: number, nx: number, nz: number, r: number) {
  if (insideUnion(nx, nz, r)) return { x: nx, z: nz, blockedX: false, blockedZ: false }
  if (insideUnion(nx, oz, r)) return { x: nx, z: oz, blockedX: false, blockedZ: true }
  if (insideUnion(ox, nz, r)) return { x: ox, z: nz, blockedX: true, blockedZ: false }
  return { x: ox, z: oz, blockedX: true, blockedZ: true }
}

// Clamp a placement point into the nearest room
export function clampToRoom(x: number, z: number, margin: number) {
  const half = GEO.half
  let best = GEO.rooms[0]
  let bestD = Number.POSITIVE_INFINITY
  for (const room of GEO.rooms) {
    const dx = Math.max(0, Math.abs(x - room.cx) - half)
    const dz = Math.max(0, Math.abs(z) - half)
    const d = dx * dx + dz * dz
    if (d < bestD) {
      bestD = d
      best = room
    }
  }
  return {
    x: clamp(x, best.cx - half + margin, best.cx + half - margin),
    z: clamp(z, -half + margin, half - margin),
  }
}

// Ground height from stairs / platforms (so hamsters can climb)
export function getGroundHeight(x: number, z: number, items: PlacedItem[]) {
  let h = 0
  for (const it of items) {
    if (it.type === "platform") {
      if (Math.abs(x - it.x) <= PLATFORM_HALF && Math.abs(z - it.z) <= PLATFORM_HALF) {
        h = Math.max(h, PLATFORM_H)
      }
    } else if (it.type === "stairs") {
      // rotate point into stair-local space (stairs climb along local +Z)
      const cos = Math.cos(-it.rotation)
      const sin = Math.sin(-it.rotation)
      const lx = (x - it.x) * cos - (z - it.z) * sin
      const lz = (x - it.x) * sin + (z - it.z) * cos
      if (Math.abs(lx) <= STAIR_W / 2 && Math.abs(lz) <= STAIR_LEN / 2) {
        const progress = clamp((lz + STAIR_LEN / 2) / STAIR_LEN, 0, 1)
        h = Math.max(h, progress * PLATFORM_H)
      }
    }
  }
  return h
}

applyGeometry("klassiek", 1)

type GameState = {
  blocks: number
  streak: number
  correctCount: number
  selectedTool: ToolType
  selectedColor: string
  items: PlacedItem[]
  hamsters: Hamster[]
  bugs: Bug[]
  theme: CageThemeId
  roomCount: number
  design: { color: string; belly: string }
  // actions
  addBlocks: (n: number) => void
  registerAnswer: (correct: boolean) => void
  setTool: (t: ToolType) => void
  setColor: (c: string) => void
  setDesign: (d: Partial<{ color: string; belly: string }>) => void
  placeItem: (type: ItemType, x: number, z: number) => boolean
  removeItem: (id: string) => void
  addHamster: (x: number, z: number) => boolean
  setHamsterTarget: (id: string, x: number, z: number) => void
  clearHamsterTarget: (id: string) => void
  growHamster: (id: string, amount: number) => void
  addBug: (x: number, z: number) => boolean
  removeBug: (id: string) => void
  eatFood: (id: string) => void
  setTheme: (t: CageThemeId) => void
  addRoom: () => boolean
  reset: () => void
}

const START_HAMSTER = (): Hamster => ({
  id: "hamster-start",
  color: FUR_COLORS[0],
  belly: BELLY_COLORS[0],
  scale: 0.85,
  startX: 0,
  startZ: 2,
  target: null,
})

export const useGame = create<GameState>((set, get) => ({
  blocks: 8,
  streak: 0,
  correctCount: 0,
  selectedTool: "walk",
  selectedColor: BLOCK_COLORS[0],
  items: [],
  hamsters: [START_HAMSTER()],
  bugs: [],
  theme: "klassiek",
  roomCount: 1,
  design: { color: FUR_COLORS[0], belly: BELLY_COLORS[0] },

  addBlocks: (n) => set((s) => ({ blocks: s.blocks + n })),

  registerAnswer: (correct) =>
    set((s) => {
      if (!correct) return { streak: 0 }
      const newStreak = s.streak + 1
      const bonus = newStreak % 3 === 0 ? 1 : 0
      return {
        blocks: s.blocks + 1 + bonus,
        streak: newStreak,
        correctCount: s.correctCount + 1,
      }
    }),

  setTool: (t) => set({ selectedTool: t }),
  setColor: (c) => set({ selectedColor: c }),
  setDesign: (d) => set((s) => ({ design: { ...s.design, ...d } })),

  placeItem: (type, x, z) => {
    const state = get()
    const cost = ITEM_COST[type]
    if (state.blocks < cost) return false
    const p = clampToRoom(x, z, 0.5)
    const item: PlacedItem = {
      id: nextId("item"),
      type,
      x: p.x,
      z: p.z,
      color: state.selectedColor,
      rotation:
        type === "tunnel" || type === "ladder" || type === "stairs"
          ? Math.round(Math.random() * 4) * (Math.PI / 2)
          : 0,
    }
    set((s) => ({ items: [...s.items, item], blocks: s.blocks - cost }))
    return true
  },

  removeItem: (id) => set((s) => ({ items: s.items.filter((i) => i.id !== id) })),

  addHamster: (x, z) => {
    const state = get()
    if (state.hamsters.length >= MAX_HAMSTERS) return false
    if (state.blocks < HAMSTER_COST) return false
    const p = clampToRoom(x, z, 0.6)
    const hamster: Hamster = {
      id: nextId("hamster"),
      color: state.design.color,
      belly: state.design.belly,
      scale: 0.7,
      startX: p.x,
      startZ: p.z,
      target: null,
    }
    set((s) => ({ hamsters: [...s.hamsters, hamster], blocks: s.blocks - HAMSTER_COST }))
    return true
  },

  setHamsterTarget: (id, x, z) => {
    const p = clampToRoom(x, z, 0.4)
    set((s) => ({
      hamsters: s.hamsters.map((h) => (h.id === id ? { ...h, target: { x: p.x, z: p.z } } : h)),
    }))
  },

  clearHamsterTarget: (id) =>
    set((s) => ({
      hamsters: s.hamsters.map((h) => (h.id === id ? { ...h, target: null } : h)),
    })),

  growHamster: (id, amount) =>
    set((s) => ({
      hamsters: s.hamsters.map((h) =>
        h.id === id ? { ...h, scale: Math.min(MAX_SCALE, h.scale + amount) } : h,
      ),
    })),

  addBug: (x, z) => {
    const state = get()
    if (state.blocks < BUG_COST) return false
    const p = clampToRoom(x, z, 0.5)
    const bug: Bug = {
      id: nextId("bug"),
      x: p.x,
      z: p.z,
      kind: BUG_KINDS[Math.floor(Math.random() * BUG_KINDS.length)],
    }
    set((s) => ({ bugs: [...s.bugs, bug], blocks: s.blocks - BUG_COST }))
    return true
  },

  removeBug: (id) => set((s) => ({ bugs: s.bugs.filter((b) => b.id !== id) })),

  eatFood: (id) =>
    set((s) => ({
      items: s.items.filter((i) => i.id !== id),
      blocks: s.blocks + 1,
    })),

  setTheme: (t) => {
    const count = get().roomCount
    applyGeometry(t, count)
    set((s) => ({
      theme: t,
      items: s.items.map((i) => {
        const p = clampToRoom(i.x, i.z, 0.5)
        return { ...i, x: p.x, z: p.z }
      }),
      bugs: s.bugs.map((b) => {
        const p = clampToRoom(b.x, b.z, 0.5)
        return { ...b, x: p.x, z: p.z }
      }),
    }))
  },

  addRoom: () => {
    const state = get()
    if (state.roomCount >= MAX_ROOMS) return false
    if (state.blocks < ROOM_COST) return false
    const newCount = state.roomCount + 1
    applyGeometry(state.theme, newCount)
    set((s) => ({ roomCount: newCount, blocks: s.blocks - ROOM_COST }))
    return true
  },

  reset: () => {
    applyGeometry("klassiek", 1)
    set({
      blocks: 8,
      streak: 0,
      correctCount: 0,
      items: [],
      bugs: [],
      theme: "klassiek",
      roomCount: 1,
      selectedTool: "walk",
      hamsters: [START_HAMSTER()],
    })
  },
}))
