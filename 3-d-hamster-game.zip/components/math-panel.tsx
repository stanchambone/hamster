"use client"

import { useEffect, useState, useCallback } from "react"
import { generateProblem, type Problem } from "@/lib/math"
import { useGame } from "@/lib/game-store"
import { cn } from "@/lib/utils"

export function MathPanel() {
  const correctCount = useGame((s) => s.correctCount)
  const streak = useGame((s) => s.streak)
  const registerAnswer = useGame((s) => s.registerAnswer)

  const [problem, setProblem] = useState<Problem | null>(null)
  const [picked, setPicked] = useState<number | null>(null)
  const [feedback, setFeedback] = useState<"good" | "bad" | null>(null)

  const newProblem = useCallback(() => {
    setProblem(generateProblem(correctCount))
    setPicked(null)
    setFeedback(null)
  }, [correctCount])

  useEffect(() => {
    setProblem(generateProblem(useGame.getState().correctCount))
  }, [])

  const handlePick = (value: number) => {
    if (!problem || feedback) return
    const correct = value === problem.answer
    setPicked(value)
    setFeedback(correct ? "good" : "bad")
    registerAnswer(correct)
    setTimeout(newProblem, correct ? 750 : 1100)
  }

  if (!problem) return null

  return (
    <div className="pointer-events-auto w-full rounded-3xl border border-border bg-card/90 p-4 shadow-lg backdrop-blur-md sm:p-5">
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Reken & verdien blokjes
        </span>
        {streak > 0 && (
          <span className="flex items-center gap-1 rounded-full bg-accent px-2.5 py-1 text-xs font-bold text-accent-foreground">
            {streak} op rij
          </span>
        )}
      </div>

      <div className="mb-4 flex items-center justify-center rounded-2xl bg-secondary py-5">
        <span className="font-mono text-3xl font-bold tabular-nums text-secondary-foreground sm:text-4xl">
          {problem.question} = ?
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        {problem.options.map((opt) => {
          const isPicked = picked === opt
          const isAnswer = opt === problem.answer
          return (
            <button
              key={opt}
              onClick={() => handlePick(opt)}
              disabled={feedback !== null}
              className={cn(
                "rounded-2xl border-2 py-3.5 text-xl font-bold tabular-nums transition-all active:scale-95",
                "border-border bg-background text-foreground hover:border-primary hover:bg-primary/10",
                feedback && isAnswer && "border-accent bg-accent text-accent-foreground",
                feedback === "bad" && isPicked && !isAnswer && "border-destructive bg-destructive/15 text-destructive",
                feedback && "cursor-default",
              )}
            >
              {opt}
            </button>
          )
        })}
      </div>

      <p className="mt-3 h-5 text-center text-sm font-medium">
        {feedback === "good" && <span className="text-accent">Goed zo! +1 blokje</span>}
        {feedback === "bad" && <span className="text-destructive">Bijna! Probeer de volgende.</span>}
      </p>
    </div>
  )
}
