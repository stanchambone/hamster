"use client"

import { Canvas } from "@react-three/fiber"
import { Environment, OrbitControls, ContactShadows } from "@react-three/drei"
import { Suspense } from "react"
import { Cage } from "./cage"
import { Hamsters } from "./hamster"
import { Bugs } from "./bugs"
import { PlacedItems } from "./placed-items"
import { CAGE_THEMES, useGame } from "@/lib/game-store"

export function Scene() {
  const themeId = useGame((s) => s.theme)
  const theme = CAGE_THEMES[themeId]
  const camDist = theme.half * 1.9 + 4

  return (
    <Canvas
      shadows
      dpr={[1, 2]}
      camera={{ position: [0, theme.half + 3, camDist], fov: 45 }}
      gl={{ antialias: true }}
    >
      <color attach="background" args={[theme.background]} />
      <fog attach="fog" args={[theme.background, theme.half * 3, theme.half * 6]} />

      <ambientLight intensity={0.6} />
      <directionalLight
        position={[6, 12, 6]}
        intensity={1.6}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-12}
        shadow-camera-right={12}
        shadow-camera-top={12}
        shadow-camera-bottom={-12}
      />
      <directionalLight position={[-6, 5, -4]} intensity={0.4} />

      <Suspense fallback={null}>
        <Cage />
        <Hamsters />
        <Bugs />
        <PlacedItems />
        <ContactShadows position={[0, 0.02, 0]} opacity={0.4} scale={theme.half * 3} blur={2.2} far={4} />
        <Environment preset="apartment" />
      </Suspense>

      <OrbitControls
        enablePan={false}
        minDistance={6}
        maxDistance={28}
        minPolarAngle={0.2}
        maxPolarAngle={Math.PI / 2.15}
        target={[0, 0.5, 0]}
        makeDefault
      />
    </Canvas>
  )
}
