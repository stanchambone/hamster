"use client"

import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import type { Group } from "three"
import { useGame, CAGE, type Hamster as HamsterData } from "@/lib/game-store"

type Runtime = {
  x: number
  z: number
  vx: number
  vz: number
  heading: number
  walkPhase: number
  idleBob: number
  bounce: number // extra hop timer when colliding
}

const FUR_DARK = "#1a1209"
const NOSE = "#d96a8a"
const EAR = "#e9b9c4"

function baseRadius(scale: number) {
  return 0.55 * scale
}

export function Hamsters() {
  const hamsters = useGame((s) => s.hamsters)
  const bugs = useGame((s) => s.bugs)
  const items = useGame((s) => s.items)
  const clearTarget = useGame((s) => s.clearHamsterTarget)
  const growHamster = useGame((s) => s.growHamster)
  const removeBug = useGame((s) => s.removeBug)
  const eatFood = useGame((s) => s.eatFood)

  // runtime state per hamster id (persists across renders, no re-render churn)
  const runtimes = useRef<Map<string, Runtime>>(new Map())
  const groups = useRef<Map<string, Group>>(new Map())
  const legRefs = useRef<Map<string, Group[]>>(new Map())

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.05)
    const list = hamsters

    // ensure runtime exists for each hamster
    for (const h of list) {
      if (!runtimes.current.has(h.id)) {
        runtimes.current.set(h.id, {
          x: h.startX,
          z: h.startZ,
          vx: 0,
          vz: 0,
          heading: 0,
          walkPhase: Math.random() * 10,
          idleBob: Math.random() * 10,
          bounce: 0,
        })
      }
    }

    // 1) intent + movement toward destination
    for (const h of list) {
      const rt = runtimes.current.get(h.id)!
      let dest = h.target as { x: number; z: number } | null

      // if no explicit target, seek nearest bug, then nearest food
      let bugTargetId: string | null = null
      let foodTargetId: string | null = null
      if (!dest) {
        let nearest: { x: number; z: number; d: number } | null = null
        for (const b of bugs) {
          const d = (b.x - rt.x) ** 2 + (b.z - rt.z) ** 2
          if (!nearest || d < nearest.d) {
            nearest = { x: b.x, z: b.z, d }
            bugTargetId = b.id
          }
        }
        if (!bugTargetId) {
          for (const it of items) {
            if (it.type !== "food") continue
            const d = (it.x - rt.x) ** 2 + (it.z - rt.z) ** 2
            if (!nearest || d < nearest.d) {
              nearest = { x: it.x, z: it.z, d }
              foodTargetId = it.id
            }
          }
        }
        if (nearest) dest = { x: nearest.x, z: nearest.z }
      }

      let moving = false
      if (dest) {
        const dx = dest.x - rt.x
        const dz = dest.z - rt.z
        const dist = Math.hypot(dx, dz)
        const reach = bugTargetId || foodTargetId ? 0.55 * h.scale + 0.2 : 0.25
        if (dist > reach) {
          moving = true
          const speed = 3.2 / Math.max(0.8, h.scale) // bigger = a touch slower
          const step = Math.min(dist, speed * dt)
          rt.x += (dx / dist) * step
          rt.z += (dz / dist) * step
          const wanted = Math.atan2(dx, dz)
          let diff = wanted - rt.heading
          while (diff > Math.PI) diff -= Math.PI * 2
          while (diff < -Math.PI) diff += Math.PI * 2
          rt.heading += diff * Math.min(1, dt * 10)
        } else {
          if (bugTargetId) {
            removeBug(bugTargetId)
            growHamster(h.id, 0.18)
          } else if (foodTargetId) {
            eatFood(foodTargetId)
            growHamster(h.id, 0.08)
          } else {
            clearTarget(h.id)
          }
        }
      }

      // store moving flag on runtime via walkPhase advance
      if (moving) {
        rt.walkPhase += dt * 12
      }
      ;(rt as Runtime & { _moving?: boolean })._moving = moving
    }

    // 2) hamster-hamster collisions -> bounce away
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = runtimes.current.get(list[i].id)!
        const b = runtimes.current.get(list[j].id)!
        const ra = baseRadius(list[i].scale)
        const rb = baseRadius(list[j].scale)
        const dx = b.x - a.x
        const dz = b.z - a.z
        let dist = Math.hypot(dx, dz)
        const minDist = ra + rb
        if (dist < minDist && dist > 0.0001) {
          const nx = dx / dist
          const nz = dz / dist
          const overlap = minDist - dist
          // separate proportional to size (lighter flies more)
          const massA = ra * ra
          const massB = rb * rb
          const total = massA + massB
          a.x -= nx * overlap * (massB / total)
          a.z -= nz * overlap * (massB / total)
          b.x += nx * overlap * (massA / total)
          b.z += nz * overlap * (massA / total)
          // impulse: fling apart
          const force = 5.5
          a.vx -= nx * force * (massB / total)
          a.vz -= nz * force * (massB / total)
          b.vx += nx * force * (massA / total)
          b.vz += nz * force * (massA / total)
          a.bounce = 0.4
          b.bounce = 0.4
        } else if (dist <= 0.0001) {
          // exactly overlapping: nudge randomly
          a.x += (Math.random() - 0.5) * 0.1
          b.x -= (Math.random() - 0.5) * 0.1
        }
      }
    }

    // 3) integrate velocity + damping + clamp to cage
    for (const h of list) {
      const rt = runtimes.current.get(h.id)!
      rt.x += rt.vx * dt
      rt.z += rt.vz * dt
      const damp = Math.pow(0.02, dt) // strong damping
      rt.vx *= damp
      rt.vz *= damp
      if (rt.bounce > 0) rt.bounce = Math.max(0, rt.bounce - dt)

      const r = baseRadius(h.scale)
      // bounce off walls
      if (rt.x < CAGE.minX + r) {
        rt.x = CAGE.minX + r
        rt.vx = Math.abs(rt.vx) * 0.4
      }
      if (rt.x > CAGE.maxX - r) {
        rt.x = CAGE.maxX - r
        rt.vx = -Math.abs(rt.vx) * 0.4
      }
      if (rt.z < CAGE.minZ + r) {
        rt.z = CAGE.minZ + r
        rt.vz = Math.abs(rt.vz) * 0.4
      }
      if (rt.z > CAGE.maxZ - r) {
        rt.z = CAGE.maxZ - r
        rt.vz = -Math.abs(rt.vz) * 0.4
      }
    }

    // 4) apply transforms + animation
    for (const h of list) {
      const rt = runtimes.current.get(h.id)!
      const g = groups.current.get(h.id)
      if (!g) continue
      const moving = (rt as Runtime & { _moving?: boolean })._moving
      const legs = legRefs.current.get(h.id) || []

      g.position.x = rt.x
      g.position.z = rt.z
      g.rotation.y = rt.heading
      g.scale.setScalar(h.scale)

      const speed = Math.hypot(rt.vx, rt.vz)
      const flying = speed > 0.4 || rt.bounce > 0

      if (moving || flying) {
        const swing = Math.sin(rt.walkPhase) * 0.6
        if (legs[0]) legs[0].rotation.x = swing
        if (legs[3]) legs[3].rotation.x = swing
        if (legs[1]) legs[1].rotation.x = -swing
        if (legs[2]) legs[2].rotation.x = -swing
        const hop = flying ? Math.abs(Math.sin(rt.walkPhase * 1.5)) * 0.25 : Math.abs(Math.sin(rt.walkPhase)) * 0.08
        g.position.y = hop
      } else {
        rt.idleBob += dt * 3
        for (const l of legs) l.rotation.x *= 0.85
        g.position.y = Math.sin(rt.idleBob) * 0.03
      }
    }
  })

  return (
    <>
      {hamsters.map((h) => (
        <HamsterMesh
          key={h.id}
          data={h}
          registerGroup={(g) => {
            if (g) groups.current.set(h.id, g)
            else groups.current.delete(h.id)
          }}
          registerLegs={(legs) => legRefs.current.set(h.id, legs)}
        />
      ))}
    </>
  )
}

function HamsterMesh({
  data,
  registerGroup,
  registerLegs,
}: {
  data: HamsterData
  registerGroup: (g: Group | null) => void
  registerLegs: (legs: Group[]) => void
}) {
  const FUR = data.color
  const FUR_LIGHT = data.belly
  const legFL = useRef<Group>(null)
  const legFR = useRef<Group>(null)
  const legBL = useRef<Group>(null)
  const legBR = useRef<Group>(null)

  return (
    <group
      ref={(g) => {
        registerGroup(g)
        registerLegs([legFL.current!, legFR.current!, legBL.current!, legBR.current!])
      }}
      position={[data.startX, 0, data.startZ]}
    >
      {/* body */}
      <mesh castShadow position={[0, 0.45, 0]}>
        <sphereGeometry args={[0.55, 32, 24]} />
        <meshStandardMaterial color={FUR} roughness={0.85} />
      </mesh>
      <mesh position={[0, 0.32, 0.18]}>
        <sphereGeometry args={[0.46, 24, 18]} />
        <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
      </mesh>
      {/* head */}
      <group position={[0, 0.62, 0.42]}>
        <mesh castShadow>
          <sphereGeometry args={[0.4, 32, 24]} />
          <meshStandardMaterial color={FUR} roughness={0.85} />
        </mesh>
        <mesh position={[-0.24, -0.08, 0.16]}>
          <sphereGeometry args={[0.2, 16, 12]} />
          <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
        </mesh>
        <mesh position={[0.24, -0.08, 0.16]}>
          <sphereGeometry args={[0.2, 16, 12]} />
          <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
        </mesh>
        <mesh position={[0, -0.06, 0.34]}>
          <sphereGeometry args={[0.16, 16, 12]} />
          <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
        </mesh>
        <mesh position={[0, -0.04, 0.48]}>
          <sphereGeometry args={[0.05, 12, 12]} />
          <meshStandardMaterial color={NOSE} roughness={0.5} />
        </mesh>
        <mesh position={[-0.16, 0.08, 0.34]}>
          <sphereGeometry args={[0.07, 16, 16]} />
          <meshStandardMaterial color={FUR_DARK} roughness={0.2} />
        </mesh>
        <mesh position={[0.16, 0.08, 0.34]}>
          <sphereGeometry args={[0.07, 16, 16]} />
          <meshStandardMaterial color={FUR_DARK} roughness={0.2} />
        </mesh>
        <mesh position={[-0.14, 0.11, 0.4]}>
          <sphereGeometry args={[0.02, 8, 8]} />
          <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.4} />
        </mesh>
        <mesh position={[0.18, 0.11, 0.4]}>
          <sphereGeometry args={[0.02, 8, 8]} />
          <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.4} />
        </mesh>
        <mesh position={[-0.26, 0.32, 0]} rotation={[0, 0, -0.3]}>
          <sphereGeometry args={[0.14, 16, 12]} />
          <meshStandardMaterial color={FUR} roughness={0.85} />
        </mesh>
        <mesh position={[0.26, 0.32, 0]} rotation={[0, 0, 0.3]}>
          <sphereGeometry args={[0.14, 16, 12]} />
          <meshStandardMaterial color={FUR} roughness={0.85} />
        </mesh>
        <mesh position={[-0.26, 0.33, 0.02]} rotation={[0, 0, -0.3]}>
          <sphereGeometry args={[0.08, 12, 10]} />
          <meshStandardMaterial color={EAR} roughness={0.8} />
        </mesh>
        <mesh position={[0.26, 0.33, 0.02]} rotation={[0, 0, 0.3]}>
          <sphereGeometry args={[0.08, 12, 10]} />
          <meshStandardMaterial color={EAR} roughness={0.8} />
        </mesh>
      </group>
      {/* legs (groups so we can rotate) */}
      <group ref={legFL} position={[-0.28, 0.12, 0.28]}>
        <mesh>
          <capsuleGeometry args={[0.09, 0.14, 4, 8]} />
          <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
        </mesh>
      </group>
      <group ref={legFR} position={[0.28, 0.12, 0.28]}>
        <mesh>
          <capsuleGeometry args={[0.09, 0.14, 4, 8]} />
          <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
        </mesh>
      </group>
      <group ref={legBL} position={[-0.3, 0.12, -0.26]}>
        <mesh>
          <capsuleGeometry args={[0.1, 0.16, 4, 8]} />
          <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
        </mesh>
      </group>
      <group ref={legBR} position={[0.3, 0.12, -0.26]}>
        <mesh>
          <capsuleGeometry args={[0.1, 0.16, 4, 8]} />
          <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
        </mesh>
      </group>
      {/* tail */}
      <mesh position={[0, 0.4, -0.52]}>
        <sphereGeometry args={[0.08, 12, 10]} />
        <meshStandardMaterial color={FUR_LIGHT} roughness={0.9} />
      </mesh>
    </group>
  )
}
