"use client"

import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import type { Group, Mesh } from "three"
import type { PlacedItem } from "@/lib/game-store"
import { useGame } from "@/lib/game-store"

function Block({ item }: { item: PlacedItem }) {
  return (
    <mesh castShadow receiveShadow position={[item.x, 0.3, item.z]}>
      <boxGeometry args={[0.6, 0.6, 0.6]} />
      <meshStandardMaterial color={item.color} roughness={0.6} />
    </mesh>
  )
}

function Wheel({ item }: { item: PlacedItem }) {
  const wheel = useRef<Group>(null)
  useFrame((_, delta) => {
    if (wheel.current) wheel.current.rotation.z += delta * 1.6
  })
  return (
    <group position={[item.x, 0, item.z]}>
      {/* stand */}
      <mesh position={[0, 0.6, -0.45]} castShadow>
        <boxGeometry args={[0.12, 1.2, 0.12]} />
        <meshStandardMaterial color="#8a8f98" metalness={0.4} roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.6, 0.45]} castShadow>
        <boxGeometry args={[0.12, 1.2, 0.12]} />
        <meshStandardMaterial color="#8a8f98" metalness={0.4} roughness={0.4} />
      </mesh>
      <group ref={wheel} position={[0, 0.85, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <mesh castShadow>
          <torusGeometry args={[0.7, 0.06, 12, 32]} />
          <meshStandardMaterial color={item.color} roughness={0.5} />
        </mesh>
        <mesh position={[0, 0, 0.3]}>
          <torusGeometry args={[0.7, 0.06, 12, 32]} />
          <meshStandardMaterial color={item.color} roughness={0.5} />
        </mesh>
        {/* rungs */}
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * Math.PI * 2
          return (
            <mesh key={i} position={[Math.cos(a) * 0.7, Math.sin(a) * 0.7, 0.15]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.025, 0.025, 0.32, 8]} />
              <meshStandardMaterial color="#e8d9c0" roughness={0.7} />
            </mesh>
          )
        })}
      </group>
    </group>
  )
}

function Tunnel({ item }: { item: PlacedItem }) {
  return (
    <group position={[item.x, 0.4, item.z]} rotation={[0, item.rotation, Math.PI / 2]}>
      <mesh castShadow>
        <cylinderGeometry args={[0.45, 0.45, 1.4, 20, 1, true]} />
        <meshStandardMaterial color={item.color} roughness={0.6} side={2} />
      </mesh>
    </group>
  )
}

function Ladder({ item }: { item: PlacedItem }) {
  return (
    <group position={[item.x, 0, item.z]} rotation={[0, item.rotation, 0]}>
      <mesh position={[-0.2, 0.7, 0]} rotation={[0.3, 0, 0]} castShadow>
        <boxGeometry args={[0.07, 1.4, 0.07]} />
        <meshStandardMaterial color="#b9854f" roughness={0.7} />
      </mesh>
      <mesh position={[0.2, 0.7, 0]} rotation={[0.3, 0, 0]} castShadow>
        <boxGeometry args={[0.07, 1.4, 0.07]} />
        <meshStandardMaterial color="#b9854f" roughness={0.7} />
      </mesh>
      {Array.from({ length: 5 }).map((_, i) => (
        <mesh key={i} position={[0, 0.2 + i * 0.28, -0.18 + i * 0.08]} castShadow>
          <boxGeometry args={[0.46, 0.05, 0.05]} />
          <meshStandardMaterial color={item.color} roughness={0.7} />
        </mesh>
      ))}
    </group>
  )
}

function Bowl({ item }: { item: PlacedItem }) {
  return (
    <group position={[item.x, 0.1, item.z]}>
      <mesh castShadow receiveShadow>
        <cylinderGeometry args={[0.42, 0.3, 0.22, 24]} />
        <meshStandardMaterial color={item.color} roughness={0.5} />
      </mesh>
      <mesh position={[0, 0.06, 0]}>
        <cylinderGeometry args={[0.34, 0.26, 0.12, 24]} />
        <meshStandardMaterial color="#caa472" roughness={0.9} />
      </mesh>
    </group>
  )
}

function Food({ item }: { item: PlacedItem }) {
  const ref = useRef<Mesh>(null)
  useFrame((state) => {
    if (ref.current) {
      ref.current.position.y = 0.16 + Math.sin(state.clock.elapsedTime * 3 + item.x) * 0.05
      ref.current.rotation.y += 0.02
    }
  })
  return (
    <group position={[item.x, 0, item.z]}>
      <mesh ref={ref} castShadow position={[0, 0.16, 0]}>
        <dodecahedronGeometry args={[0.16, 0]} />
        <meshStandardMaterial color="#e0a13b" emissive="#3a2200" emissiveIntensity={0.2} roughness={0.6} />
      </mesh>
    </group>
  )
}

export function PlacedItems() {
  const items = useGame((s) => s.items)
  const selectedTool = useGame((s) => s.selectedTool)
  const removeItem = useGame((s) => s.removeItem)

  return (
    <>
      {items.map((item) => {
        const handleClick = (e: any) => {
          // only build tools remove items; walk/hamster/bug should pass through to the floor
          if (selectedTool === "walk" || selectedTool === "hamster" || selectedTool === "bug") return
          e.stopPropagation()
          removeItem(item.id)
        }
        return (
          <group key={item.id} onClick={handleClick}>
            {item.type === "block" && <Block item={item} />}
            {item.type === "wheel" && <Wheel item={item} />}
            {item.type === "tunnel" && <Tunnel item={item} />}
            {item.type === "ladder" && <Ladder item={item} />}
            {item.type === "bowl" && <Bowl item={item} />}
            {item.type === "food" && <Food item={item} />}
          </group>
        )
      })}
    </>
  )
}
