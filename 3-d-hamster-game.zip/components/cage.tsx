"use client"

import { useMemo } from "react"
import type { ThreeEvent } from "@react-three/fiber"
import { CAGE, CAGE_THEMES, useGame } from "@/lib/game-store"

const WALL_H = 2.2

export function Cage() {
  const selectedTool = useGame((s) => s.selectedTool)
  const setHamsterTarget = useGame((s) => s.setHamsterTarget)
  const placeItem = useGame((s) => s.placeItem)
  const addHamster = useGame((s) => s.addHamster)
  const addBug = useGame((s) => s.addBug)
  const hamsters = useGame((s) => s.hamsters)
  const themeId = useGame((s) => s.theme)

  const theme = CAGE_THEMES[themeId]
  const half = theme.half
  const width = half * 2
  const depth = half * 2

  // scattered bedding bits for texture (regenerate when theme/size changes)
  const bedding = useMemo(() => {
    const arr: { x: number; z: number; s: number; c: string }[] = []
    const count = Math.round((width * depth) * 0.9)
    for (let i = 0; i < count; i++) {
      arr.push({
        x: -half + Math.random() * width,
        z: -half + Math.random() * depth,
        s: 0.1 + Math.random() * 0.18,
        c: theme.bedding[Math.floor(Math.random() * theme.bedding.length)],
      })
    }
    return arr
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [themeId, half])

  const handleFloorClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation()
    const { x, z } = e.point
    if (selectedTool === "walk") {
      // move ALL hamsters toward the click (party walk), or the single one
      for (const h of hamsters) setHamsterTarget(h.id, x, z)
    } else if (selectedTool === "hamster") {
      addHamster(x, z)
    } else if (selectedTool === "bug") {
      addBug(x, z)
    } else {
      placeItem(selectedTool, x, z)
    }
  }

  return (
    <group>
      {/* base under cage */}
      <mesh position={[0, -0.35, 0]} receiveShadow>
        <boxGeometry args={[width + 1.2, 0.6, depth + 1.2]} />
        <meshStandardMaterial color={theme.base} roughness={0.9} />
      </mesh>

      {/* floor (clickable) */}
      <mesh
        position={[0, 0.001, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        receiveShadow
        onClick={handleFloorClick}
      >
        <planeGeometry args={[width, depth]} />
        <meshStandardMaterial color={theme.floor} roughness={1} />
      </mesh>

      {/* bedding flecks */}
      {bedding.map((b, i) => (
        <mesh key={i} position={[b.x, 0.03, b.z]} rotation={[-Math.PI / 2, 0, Math.random() * Math.PI]}>
          <circleGeometry args={[b.s, 6]} />
          <meshStandardMaterial color={b.c} roughness={1} />
        </mesh>
      ))}

      {/* glass walls */}
      <GlassWall position={[0, WALL_H / 2, -half]} args={[width, WALL_H, 0.1]} color={theme.glass} />
      <GlassWall position={[0, WALL_H / 2, half]} args={[width, WALL_H, 0.1]} color={theme.glass} />
      <GlassWall position={[-half, WALL_H / 2, 0]} args={[0.1, WALL_H, depth]} color={theme.glass} />
      <GlassWall position={[half, WALL_H / 2, 0]} args={[0.1, WALL_H, depth]} color={theme.glass} />

      {/* wooden top rim */}
      {[
        { p: [0, WALL_H, -half] as const, a: [width + 0.3, 0.18, 0.3] as const },
        { p: [0, WALL_H, half] as const, a: [width + 0.3, 0.18, 0.3] as const },
        { p: [-half, WALL_H, 0] as const, a: [0.3, 0.18, depth + 0.3] as const },
        { p: [half, WALL_H, 0] as const, a: [0.3, 0.18, depth + 0.3] as const },
      ].map((r, i) => (
        <mesh key={i} position={r.p as unknown as [number, number, number]} castShadow>
          <boxGeometry args={r.a as unknown as [number, number, number]} />
          <meshStandardMaterial color={theme.rim} roughness={0.7} />
        </mesh>
      ))}
    </group>
  )
}

function GlassWall({
  position,
  args,
  color,
}: {
  position: [number, number, number]
  args: [number, number, number]
  color: string
}) {
  return (
    <mesh position={position}>
      <boxGeometry args={args} />
      <meshPhysicalMaterial
        color={color}
        transparent
        opacity={0.18}
        roughness={0.05}
        transmission={0.6}
        thickness={0.2}
      />
    </mesh>
  )
}
