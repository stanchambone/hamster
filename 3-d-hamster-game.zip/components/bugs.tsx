"use client"

import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import type { Group } from "three"
import { useGame, CAGE, type Bug as BugData } from "@/lib/game-store"

type BugRuntime = {
  x: number
  z: number
  heading: number
  turnTimer: number
  wiggle: number
}

export function Bugs() {
  const bugs = useGame((s) => s.bugs)
  const runtimes = useRef<Map<string, BugRuntime>>(new Map())
  const groups = useRef<Map<string, Group>>(new Map())

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.05)
    for (const b of bugs) {
      let rt = runtimes.current.get(b.id)
      if (!rt) {
        rt = { x: b.x, z: b.z, heading: Math.random() * Math.PI * 2, turnTimer: 0, wiggle: Math.random() * 10 }
        runtimes.current.set(b.id, rt)
      }
      // wander: change heading occasionally
      rt.turnTimer -= dt
      if (rt.turnTimer <= 0) {
        rt.heading += (Math.random() - 0.5) * 1.6
        rt.turnTimer = 0.6 + Math.random() * 1.2
      }
      const speed = b.kind === "sprinkhaan" ? 1.4 : b.kind === "kever" ? 0.9 : 0.5
      rt.x += Math.sin(rt.heading) * speed * dt
      rt.z += Math.cos(rt.heading) * speed * dt
      rt.wiggle += dt * 14

      // bounce off walls
      const m = 0.4
      if (rt.x < CAGE.minX + m || rt.x > CAGE.maxX - m) {
        rt.heading = -rt.heading + Math.PI
        rt.x = Math.max(CAGE.minX + m, Math.min(CAGE.maxX - m, rt.x))
      }
      if (rt.z < CAGE.minZ + m || rt.z > CAGE.maxZ - m) {
        rt.heading = Math.PI - rt.heading
        rt.z = Math.max(CAGE.minZ + m, Math.min(CAGE.maxZ - m, rt.z))
      }

      const g = groups.current.get(b.id)
      if (g) {
        g.position.x = rt.x
        g.position.z = rt.z
        g.rotation.y = rt.heading
        // little hop for grasshopper, wiggle for others
        if (b.kind === "sprinkhaan") {
          g.position.y = Math.abs(Math.sin(rt.wiggle * 0.5)) * 0.18
        } else {
          g.position.y = 0.02 + Math.sin(rt.wiggle) * 0.01
        }
      }
    }
  })

  return (
    <>
      {bugs.map((b) => (
        <group
          key={b.id}
          ref={(g) => {
            if (g) groups.current.set(b.id, g)
            else groups.current.delete(b.id)
          }}
          position={[b.x, 0.02, b.z]}
        >
          <BugBody kind={b.kind} />
        </group>
      ))}
    </>
  )
}

function BugBody({ kind }: { kind: BugData["kind"] }) {
  if (kind === "worm") {
    return (
      <group>
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} castShadow position={[0, 0.07, -i * 0.12]}>
            <sphereGeometry args={[0.08 - i * 0.008, 12, 10]} />
            <meshStandardMaterial color="#e08a6a" roughness={0.6} />
          </mesh>
        ))}
      </group>
    )
  }
  if (kind === "sprinkhaan") {
    return (
      <group>
        <mesh castShadow position={[0, 0.1, 0]}>
          <capsuleGeometry args={[0.07, 0.2, 4, 10]} />
          <meshStandardMaterial color="#6fae4e" roughness={0.5} />
        </mesh>
        <mesh position={[0, 0.16, 0.16]}>
          <sphereGeometry args={[0.08, 12, 10]} />
          <meshStandardMaterial color="#7cc057" roughness={0.5} />
        </mesh>
        {/* back legs */}
        <mesh position={[0.1, 0.05, -0.1]} rotation={[0, 0, -0.6]}>
          <capsuleGeometry args={[0.02, 0.16, 4, 6]} />
          <meshStandardMaterial color="#5a9440" />
        </mesh>
        <mesh position={[-0.1, 0.05, -0.1]} rotation={[0, 0, 0.6]}>
          <capsuleGeometry args={[0.02, 0.16, 4, 6]} />
          <meshStandardMaterial color="#5a9440" />
        </mesh>
      </group>
    )
  }
  // kever (beetle)
  return (
    <group>
      <mesh castShadow position={[0, 0.08, 0]}>
        <sphereGeometry args={[0.13, 16, 12]} />
        <meshStandardMaterial color="#3a2a1a" roughness={0.3} metalness={0.4} />
      </mesh>
      <mesh position={[0, 0.12, 0.02]} scale={[1, 0.6, 1.1]}>
        <sphereGeometry args={[0.12, 16, 12]} />
        <meshStandardMaterial color="#52341f" roughness={0.2} metalness={0.5} />
      </mesh>
      <mesh position={[0, 0.08, 0.14]}>
        <sphereGeometry args={[0.06, 12, 10]} />
        <meshStandardMaterial color="#241608" roughness={0.3} />
      </mesh>
    </group>
  )
}
