"use client"

import {
  ITEM_COST,
  BLOCK_COLORS,
  HAMSTER_COST,
  BUG_COST,
  MAX_HAMSTERS,
  CAGE_THEMES,
  useGame,
  type ToolType,
  type CageThemeId,
} from "@/lib/game-store"
import { cn } from "@/lib/utils"
import { Footprints, Box, Disc, Cylinder, ArrowUpRight, Soup, Wheat, Trash2, Rat, Bug } from "lucide-react"

const TOOLS: { id: ToolType; label: string; icon: typeof Box; cost?: number }[] = [
  { id: "walk", label: "Lopen", icon: Footprints },
  { id: "hamster", label: "Hamster", icon: Rat, cost: HAMSTER_COST },
  { id: "bug", label: "Insect", icon: Bug, cost: BUG_COST },
  { id: "block", label: "Blok", icon: Box, cost: ITEM_COST.block },
  { id: "wheel", label: "Rad", icon: Disc, cost: ITEM_COST.wheel },
  { id: "tunnel", label: "Tunnel", icon: Cylinder, cost: ITEM_COST.tunnel },
  { id: "ladder", label: "Ladder", icon: ArrowUpRight, cost: ITEM_COST.ladder },
  { id: "bowl", label: "Bak", icon: Soup, cost: ITEM_COST.bowl },
  { id: "food", label: "Voer", icon: Wheat, cost: ITEM_COST.food },
]

const THEME_ORDER: CageThemeId[] = ["klassiek", "bos", "woestijn", "ijs"]

export function BuildToolbar() {
  const selectedTool = useGame((s) => s.selectedTool)
  const setTool = useGame((s) => s.setTool)
  const selectedColor = useGame((s) => s.selectedColor)
  const setColor = useGame((s) => s.setColor)
  const blocks = useGame((s) => s.blocks)
  const reset = useGame((s) => s.reset)
  const theme = useGame((s) => s.theme)
  const setTheme = useGame((s) => s.setTheme)
  const hamsterCount = useGame((s) => s.hamsters.length)

  const showColors = !["walk", "food", "hamster", "bug"].includes(selectedTool)

  return (
    <div className="pointer-events-auto w-full rounded-3xl border border-border bg-card/90 p-4 shadow-lg backdrop-blur-md">
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Bouw je kooi
        </span>
        <button
          onClick={reset}
          className="flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
        >
          <Trash2 className="size-3.5" />
          Opnieuw
        </button>
      </div>

      <div className="grid grid-cols-3 gap-2 sm:grid-cols-5 lg:grid-cols-3">
        {TOOLS.map((tool) => {
          const Icon = tool.icon
          const active = selectedTool === tool.id
          const isHamster = tool.id === "hamster"
          const hamsterFull = isHamster && hamsterCount >= MAX_HAMSTERS
          const tooExpensive = (tool.cost != null && blocks < tool.cost) || hamsterFull
          return (
            <button
              key={tool.id}
              onClick={() => setTool(tool.id)}
              disabled={hamsterFull}
              className={cn(
                "flex flex-col items-center gap-1 rounded-2xl border-2 py-2.5 transition-all active:scale-95",
                active
                  ? "border-primary bg-primary text-primary-foreground shadow-md"
                  : "border-border bg-background text-foreground hover:border-primary/60",
                tooExpensive && !active && "opacity-50",
              )}
            >
              <Icon className="size-5" />
              <span className="text-[11px] font-semibold leading-none">{tool.label}</span>
              {isHamster ? (
                <span
                  className={cn(
                    "text-[10px] font-bold leading-none",
                    active ? "text-primary-foreground/80" : "text-muted-foreground",
                  )}
                >
                  {hamsterCount}/{MAX_HAMSTERS}
                </span>
              ) : (
                tool.cost != null && (
                  <span
                    className={cn(
                      "text-[10px] font-bold leading-none",
                      active ? "text-primary-foreground/80" : "text-muted-foreground",
                    )}
                  >
                    {tool.cost} blok
                  </span>
                )
              )}
            </button>
          )
        })}
      </div>

      {showColors && (
        <div className="mt-3 flex items-center gap-2">
          <span className="text-xs font-medium text-muted-foreground">Kleur:</span>
          <div className="flex gap-1.5">
            {BLOCK_COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                aria-label={`Kies kleur ${c}`}
                className={cn(
                  "size-7 rounded-full border-2 transition-transform active:scale-90",
                  selectedColor === c ? "scale-110 border-foreground" : "border-border",
                )}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Cage theme / starter base picker */}
      <div className="mt-3 border-t border-border pt-3">
        <span className="text-xs font-medium text-muted-foreground">Kooi-basis:</span>
        <div className="mt-1.5 grid grid-cols-4 gap-1.5">
          {THEME_ORDER.map((id) => {
            const t = CAGE_THEMES[id]
            const active = theme === id
            return (
              <button
                key={id}
                onClick={() => setTheme(id)}
                className={cn(
                  "flex flex-col items-center gap-1 rounded-xl border-2 py-1.5 transition-all active:scale-95",
                  active ? "border-primary shadow-sm" : "border-border hover:border-primary/60",
                )}
              >
                <span
                  className="size-5 rounded-md border border-border"
                  style={{ backgroundColor: t.swatch }}
                />
                <span className="text-[10px] font-semibold leading-none text-foreground">{t.label}</span>
              </button>
            )
          })}
        </div>
      </div>

      <p className="mt-3 text-center text-xs text-muted-foreground">
        {selectedTool === "walk"
          ? "Klik in de kooi: je hamsters lopen erheen."
          : selectedTool === "hamster"
            ? "Klik in de kooi om een hamster erbij te zetten (max 10)."
            : selectedTool === "bug"
              ? "Klik om een levend insect los te laten. Hamsters eten ze op en groeien!"
              : "Klik in de kooi om te plaatsen. Klik op een voorwerp om het weg te halen."}
      </p>
    </div>
  )
}
