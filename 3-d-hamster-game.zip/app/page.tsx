"use client"

import dynamic from "next/dynamic"
import { useGame } from "@/lib/game-store"
import { MathPanel } from "@/components/math-panel"
import { BuildToolbar } from "@/components/build-toolbar"
import { Box } from "lucide-react"
import { Rat } from "lucide-react"

const Scene = dynamic(() => import("@/components/scene").then((m) => m.Scene), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-secondary">
      <p className="animate-pulse text-lg font-semibold text-muted-foreground">
        De hamster wordt wakker...
      </p>
    </div>
  ),
})

export default function Page() {
  const blocks = useGame((s) => s.blocks)
  const correctCount = useGame((s) => s.correctCount)
  const hamsterCount = useGame((s) => s.hamsters.length)

  return (
    <main className="relative h-screen w-full overflow-hidden">
      {/* 3D world */}
      <div className="absolute inset-0">
        <Scene />
      </div>

      {/* Top HUD */}
      <header className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-4">
        <div className="pointer-events-auto rounded-2xl border border-border bg-card/90 px-4 py-2.5 shadow-md backdrop-blur-md">
          <h1 className="text-base font-bold leading-tight text-foreground sm:text-lg">
            Rekenhamster <span className="text-primary">3D</span>
          </h1>
          <p className="text-[11px] text-muted-foreground">Reken goed, bouw mee!</p>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <div className="flex items-center gap-2 rounded-2xl border border-border bg-card/90 px-4 py-2.5 shadow-md backdrop-blur-md">
            <Box className="size-5 text-primary" />
            <span className="text-xl font-bold tabular-nums text-foreground">{blocks}</span>
            <span className="text-xs text-muted-foreground">blokjes</span>
          </div>
          <div className="flex items-center gap-2 rounded-2xl border border-border bg-card/90 px-4 py-2.5 shadow-md backdrop-blur-md">
            <Rat className="size-5 text-accent" />
            <span className="text-xl font-bold tabular-nums text-foreground">{hamsterCount}</span>
            <span className="hidden text-xs text-muted-foreground sm:inline">hamsters</span>
          </div>
          <div className="hidden rounded-2xl border border-border bg-card/90 px-4 py-2.5 shadow-md backdrop-blur-md sm:block">
            <span className="text-xl font-bold tabular-nums text-accent">{correctCount}</span>
            <span className="ml-1 text-xs text-muted-foreground">goed</span>
          </div>
        </div>
      </header>

      {/* Panels */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex flex-col gap-3 p-4 lg:inset-y-0 lg:right-auto lg:w-80 lg:justify-center">
        <div className="lg:order-2">
          <BuildToolbar />
        </div>
        <div className="lg:order-1">
          <MathPanel />
        </div>
      </div>
    </main>
  )
}
